#include "Arena.h"
//To be completed
Arena::Arena(){

}
virtual Arena::~Arena(){

}

bool Arena::isGameOver() const{

}

void Arena::removeObject(Object*){

}
void Arena::addObject(Object*){

}

void Arena::getConstObjects(const Object**&, int&) const{

}

Object* Arena::getObjectAt(int aX, int aY) const{

}

void Arena::nextRound(){

}

void Arena::addBuilding(int, int, int){

}

bool Arena::upgrade(Tower*){

}
