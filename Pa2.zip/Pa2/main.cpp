#include "Controller.h"

int main()
{
	Controller c;
	c.run();
	return 0;
}

